


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: Human_GULO_pseudogene     2336 bp
Sequence 2: Rat_GULO_functional       2336 bp
Sequence 3: Mouse_GULO_functional     2336 bp
Sequence 4: Dog_GULO_functional       2336 bp

           Human_GULO_pseudogene 
           Rat_GULO_functional 
           Mouse_GULO_functional 
           Dog_GULO_functional 
           Rat_GULO_functional 
           Mouse_GULO_functional 
           Dog_GULO_functional 
           Mouse_GULO_functional 
           Dog_GULO_functional 
           Dog_GULO_functional 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/clustalo/interactive/20260411/0826/clustalo-I20260411-082647-0894-30339463-p1m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/clustalo/interactive/20260411/0826/clustalo-I20260411-082647-0894-30339463-p1m.sqr.ph]

