(
Human_GULO_pseudogene:0.20609,
(
Rat_GULO_functional:0.06193,
Mouse_GULO_functional:0.05785)
:0.01037,
Dog_GULO_functional:0.06013);
